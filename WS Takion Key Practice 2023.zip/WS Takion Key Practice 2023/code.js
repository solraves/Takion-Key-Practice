// todo negative marking for wrong

var exchangeList = ['ARCA','NSDQ','EDGX','EDGA','IEX','DKL','MIDP','CHSX','BATS','BATY','BOSX','NYSE','NSEX','PHLX', 'MEMX','MIAX'];

var buyDict = {
  "ARCA": ["A"],
  "NSDQ": ["AA","X"],
  "EDGX": ["AAA"],
  "EDGA": ["AAAA"],
  "IEX":  ["S"],
  "DKL":  ["SS"],
  "MIDP": ["SSS"],
  "CHSX": ["SSSS", "XXXX" ],
  "BATS": ["DD","Z"],
  "BATY": ["DDD","ZZ"],
  "BOSX": ["D","ZZZ"],
  "PHLX": ["DDDD","XXXXX"],
  "NYSE": ["C","XX"],
  "NSEX": ["XXX"],
  "AMEX": ["a"], // correct later, use Ctrl + a 
  "MEMX": ["ZZZZ"],
  "MIAX": ["ZZZZZ"],
  "AGGRESSIVE" : ["O"]
};

var sellDict = {
  "ARCA": ["L"],
  "NSDQ": ["LL",">"],
  "EDGX": ["LLL"],
  "EDGA": ["LLLL"],
  "IEX":  [":"],
  "DKL":  ["::"],
  "MIDP": [":::"],
  "CHSX": ["::::", ">>>>"],
  "BATS": ["\"\"", "?"],
  "BATY": ["\"\"\"","??"],
  "BOSX": ["\"","???"],
  "PHLX": ["\"\"\"\"", ">>>>>"],
  "NYSE": [">>"],
  "NSEX": [">>>"],
  "AMEX": ["l"], // correct later, use Ctrl + a 
  "MEMX": ["????"],
  "MIAX": ["?????"],
  "AGGRESSIVE" : ["W"]
};

var x = 15;
var y = 40;
var score = 0;
var gameover = 10;
var text2 = "";
var text1 = "";
var TextInput = "";
var uiText = "";
var speed = 1000000;
var random_boolean = false;

onEvent("StartButton", "click", function() {
  console.log("StartButton clicked!");
  setScreen("Game");
  playGame();
  timedLoop(speed, updateWord);
});

onEvent("Input", "keydown", function(event ) {
   if (event.key === "Enter") {
    TextInput = getText("Input").trim();
    console.log("Input current text: " +TextInput );
    console.log("The text is: " + text1);
    var input = TextInput;
    if (input == text1 || input == text2) {
      setText("Score", ++score);
      setText("Input", "");
      playGame();
    } 
   }
});


function playGame() {
  var n = randomNumber(0, exchangeList.length - 1);

  y = 170;
  gameover = 10;
  
  random_boolean = Math.random() < 0.5;
  // console.log("The random boolean is: " + random_boolean);
   
  var exchange = exchangeList[n];
  
  if (random_boolean ==true)
  {
    setProperty("Game", "background-color", 'Green');
    text1 = buyDict[exchange][0];
    text2 = buyDict[exchange][1];
    uiText = "Long " + exchange;
  }
  else
  {
    setProperty("Game", "background-color", 'red');
    text1 = sellDict[exchange][0];
    text2 = sellDict[exchange][1];
    uiText = "Short " + exchange;
  }
  console.log("The text is: " + text1 + "or " + text2);
  // todo: change color instead of showing buy/sell
  
  setText("Word", uiText);
  setPosition("Word", x, y);
}

function updateWord () {
  y += 28;
  setPosition("Word", x, y);
  if (--gameover < 0) {
    gameOver();
  }
  
  stopTimedLoop();
  timedLoop(speed -= 10, updateWord);
}

function gameOver() {
  stopTimedLoop();
  setScreen("EndGame");
  setText("FinalScore", score);
}
onEvent("Welcome", "keydown", function(event) {
	console.log("Key pressed: " + event.key);
});
onEvent("Game", "click", function( ) {
	console.log("Game clicked!");
});
onEvent("Input", "input", function( ) {
	console.log("Input current text: " + getText("Input"));
});
